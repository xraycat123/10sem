import 'package:sqflite/sqflite.dart';
import 'dart:async';
import 'dart:io';
import 'package:path_provider/path_provider.dart';
import 'package:path/path.dart';
import '../models/note.dart';

class DbHandler {
//  insert();
  // fetch();
  //update();

  //getSamples()

  DbHandler._();

  static final DbHandler db = DbHandler._();

  Database _database;

  Future<Database> get database async {
    if (_database != null) return _database;

    // if _database is null we instantiate it
    _database = await initDB();
    return _database;
  }

  initDB() async {
    Directory documentsDirectory = await getApplicationDocumentsDirectory();
    String path = join(documentsDirectory.path, "TestDB.db");
    return await openDatabase(path, version: 1, onOpen: (db) {},
        onCreate: (Database db, int version) async {
      await db.execute("CREATE TABLE Note ("
          "id INTEGER PRIMARY KEY,"
          "text TEXT,"
          "category TEXT,"
          "annotator TEXT"
          ")");
      var fido =
      Note(text: 'The movie was great. i loved it for sure', category: 'good', annotator: 'martin');
      DbHandler.db.newNote(fido);

      for(var i = 0; i<15; i++){


      Note(text: 'The movie was no great.', category: 'bad', annotator: 'martin');
      DbHandler.db.newNote(fido);
      fido= Note(text: 'wow just wow', category: 'good', annotator: '');
      DbHandler.db.newNote(fido);
      Note(text: 'The movie was great. i loved it for sure', category: 'good', annotator: 'martin');
      DbHandler.db.newNote(fido);
      Note(text: 'The movie was no great.', category: 'bad', annotator: 'martin');
      DbHandler.db.newNote(fido);
      fido= Note(text: 'wow just wow', category: 'good', annotator: '');
      DbHandler.db.newNote(fido);
      }
   print('yolo');
    });


  }

//  this.id,
//  this.text,
//  this.category,
//  this.annotator,

  newNote(Note newNote) async {
    final db = await database;
    var res = await db.insert("Note", newNote.toMap());
    return res;
  }

  getNote(int id) async {
    final db = await database;
    var res = await db.query("Note", where: "id = ?", whereArgs: [id]);
    return res.isNotEmpty ? Note.fromJson(res.first) : Null;
  }

  Future<List<Note>> notes() async {
    // Get a reference to the database
    final Database db = await database;

    // Query the table for All The Dogs.
    final List<Map<String, dynamic>> maps = await db.query('Note');

    // Convert the List<Map<String, dynamic> into a List<Dog>.
    return List.generate(maps.length, (i) {
      return Note(
          id: maps[i]['id'],
          text: maps[i]['text'],
          category: maps[i]['category'],
          annotator: maps[i]['annotator']);
    });
    // print(await dogs()); // Prints a list that include Fido
  }

}
