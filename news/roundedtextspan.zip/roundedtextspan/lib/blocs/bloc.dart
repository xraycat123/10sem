import 'dart:async';

import 'package:roundedtextspan/db/dbHandler.dart';
import 'package:roundedtextspan/models/note.dart';

class NotesBloc {
  NotesBloc() {
    getNotes();
  }

  final _notesController = StreamController<List<Note>>.broadcast();

  get notes => _notesController.stream;

  dispose() {
    _notesController.close();
  }

  getNotes() async {
    _notesController.sink.add(await DbHandler.db.notes());
  }

  add(Note note) {
    DbHandler.db.newNote(note);
    getNotes();
  }
}
