//import 'package:flutter/material.dart';
//
//void main() => runApp(new MyApp());
//
//class MyApp extends StatelessWidget {
//  @override
//  Widget build(BuildContext context) {
//    return MaterialApp(
//      home: Scaffold(
//        appBar: new AppBar(),
//        body: new RichText(
//          text: new TextSpan(
//            text: null,
//            style: TextStyle(fontSize: 20.0, color: Colors.black),
//            children: <TextSpan>[
//              new TextSpan(
//                text: 'inactive ',),
//              new TextSpan(
//                  text: 'active',
//                  style: TextStyle(
//                      fontSize: 20.0,
//                      color: Colors.black,
//                      background: Paint()
//                        ..style = PaintingStyle.stroke
//                        ..strokeCap = StrokeCap.round
//                        ..color = Colors.blue
//                        ..strokeWidth = 4.0
//
//
//
//
//                  )
//              ),
//            ],
//          ),
//        ),
//      ),
//    );
//  }
//}
