import 'dart:convert';

Note noteFromJson(String str) {
  final jsonData = json.decode(str);
  return Note.fromJson(jsonData);
}

String noteToJson(Note data) {
  final dyn = data.toJson();
  return json.encode(dyn);
}

class Note {
  int id;
  String text;
  String category;
  String annotator;

  Note({
    this.id,
    this.text,
    this.category,
    this.annotator,
  });

  factory Note.fromJson(Map<String, dynamic> json) => new Note(
    id: json["id"],
    text: json["text"],
    category: json["category"],
    annotator: json["annotator"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "text": text,
    "category": category,
    "annotator": annotator,
  };

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'text': text,
      'category': category,
      'annotator': annotator,
    };
  }
  @override
  String toString() {

    return (text +" "+ id.toString());
  }




}
