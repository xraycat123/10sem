import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'dart:async';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:roundedtextspan/db/dbHandler.dart';
import 'package:roundedtextspan/models/note.dart';
import 'package:roundedtextspan/blocs/bloc.dart';
//void main() => runApp(new MyApp());

void main() {
  //DbHandler.db.initDB();
  runApp(MaterialApp(
    title: 'ECG note',
    home: MyApp(),
    theme: ThemeData(
        primaryColor: PrimaryColor,
        pageTransitionsTheme: PageTransitionsTheme(builders: {
          TargetPlatform.android: CupertinoPageTransitionsBuilder(),
        })),
  ));
}

//--release --no-track-widget-creation
//TapGestureRecognizer _recognizer1;
//DoubleTapGestureRecognizer _recognizer2;
//LongPressGestureRecognizer _recognizer3;
final String assetName = 'assets/tagster.svg';

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      child: Scaffold(
        drawer: Drawer(
          // Add a ListView to the drawer. This ensures the user can scroll
          // through the options in the Drawer if there isn't enough vertical
          // space to fit everything.
          child: ListView(
            // Important: Remove any padding from the ListView.
            padding: EdgeInsets.zero,
            children: <Widget>[
              DrawerHeader(
                child: Container(
                  padding: EdgeInsets.all(50),
                  child: SvgPicture.asset(
                    assetName,
                  ),
                ),
              ),
//              DrawerHeader(
//                child: Text('Drawer Header'),
//
//                decoration: BoxDecoration(
//                  color: Colors.blue,
//                ),
//              ),
              ListTile(
                title: Text('Statistics'),
                trailing: Icon(Icons.arrow_forward),
                onTap: () {
                  Navigator.pop(context);
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => FirstPage()),
                  );
                  // Update the state of the app
                  // ...
                },
              ),
              ListTile(
                title: Text('Patients'),
                trailing: Icon(Icons.arrow_forward),
                onTap: () async {
                  print(await DbHandler.db.notes());
                  Navigator.pop(context);
                  // Update the state of the app
                  // ...
                },
              ),
              ListTile(
                title: Text('Create note'),
                trailing: Icon(Icons.arrow_forward),
                onTap: () {
                  Navigator.pop(context);
                  // Update the state of the app
                  // ...
                },
              ),
            ],
          ),
        ),
        appBar: new AppBar(
          title: Row(
            children: <Widget>[
              Text('Verify note '),
              //  Image.asset("assets/mus.png", fit: BoxFit.cover)
            ],
          ),
        ),
        bottomNavigationBar: BottomAppBar(
          child: Container(
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: <Widget>[
                MaterialButton(
                  minWidth: 100,
                  padding: const EdgeInsets.all(8.0),
                  textColor: Colors.white,
                  color: Color.fromRGBO(157, 187, 29, 1),
                  onPressed: () {
                    print('Fis');
                  },
                  child: Row(
                    children: <Widget>[Text("Verify"), Icon(Icons.check)],
                  ),
                  splashColor: Colors.white,
                ),
                MaterialButton(
                  minWidth: 100,
                  onPressed: () {
                    print('Hus');
                  },
                  textColor: Colors.white,
                  color: Color.fromRGBO(223, 103, 82, 1),
                  splashColor: Colors.white,
                  padding: const EdgeInsets.all(8.0),
                  child: Row(
                    children: <Widget>[
                      Text(
                        "Reject",
                      ),
                      Icon(Icons.close),
                    ],
                  ),
                ),
              ],
            ),
            height: 50.0,
          ),
        ),
        body: SingleChildScrollView(
          child: Column(
            children: <Widget>[
              Counter(),
              //   Container(height: 80.0, color: Colors.blue[300]),
            ],
          ),
        ),
      ),
    );
  }
}

class Counter extends StatefulWidget {
  // The state is stored not in the widget, but in the specific class
  // that is created by createState()
  @override
  State<Counter> createState() => _CounterState();
// The result of the function is an object, that must be
// of the type State<Counter> (where Counter is the name of our widget)

}

class _CounterState extends State<Counter> {
  // Finally, we can declare dynamic variables inside of our classes,
  // to store the state of our widgets

  // In this case, we'll store the number
  int counter = 0;
  bool tapBool = false;

  // The rest is super simple, we just implement the familiar to us build() method,
  // in the same way as we did it for our [StatelessWidget]
  @override
  Widget build(BuildContext context) {
    // Almost nothing has changed since the last example.
    // I've added comments to highlight the difference
    return Center(
      child: GestureDetector(
        onTap: () {
          // Once the button is tapped we increase the value of [counter] variable
          setState(() {
            // Using setState() is required to trigger lifecycle hooks
            // so the widget will know that it should be updated
            ++counter;
            print(counter);
          });
        },
        child: Card(
          margin: EdgeInsets.all(30.0),
          elevation: 5.0,
          child: Column(
            children: [
              Container(
                padding: EdgeInsets.all(10.0),
                constraints: BoxConstraints(minHeight: 150.0),
                //margin: EdgeInsets.all(30.0),
                //  alignment: AlignmentDirectional(0.0, 0.0),       --release --no-track-widget-creation
                child: RichText(
                    text:
                        TextSpan(children: manyWord(' ' + counter.toString()))),
              ),
              Container(
                alignment: Alignment.bottomRight,
                child: Padding(
                  padding: const EdgeInsets.all(5.0),
                  child: RichText(
                      text: TextSpan(
                          text: 'Patient iddd: 9785, 19-05-2018',
                          style: TextStyle(
                              color: Color.fromRGBO(162, 172, 182, 1),
                              fontSize: 12))),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  List<TextSpan> manyWord(i) {
    return [
      word('The patient is very sick and may have '),
      word('atrial flutter', mark: true),
      word(' . Confirmed.'),
      word(i),
    ];
  }

  TextSpan word(w, {mark = false}) {
    if (mark == false) {
      return TextSpan(
          text: w, style: TextStyle(color: Colors.black, fontSize: 20));
    } else if (tapBool == false) {
      print('sss');
      return TextSpan(
          recognizer: TapGestureRecognizer()..onTap = () => {wordTap()},
          text: w,
          style: TextStyle(
            decoration: TextDecoration.underline,
            decorationStyle: TextDecorationStyle.dotted,
            background: paint,
            color: Colors.black,
            fontSize: 20,
          ));
    } else if (tapBool == true) {
      print('aasdsd');
      return TextSpan(
          recognizer: TapGestureRecognizer()..onTap = () => {wordTap()},
          text: w,
          style: TextStyle(
            color: Colors.black,
            fontSize: 20,
          ));
    }
  } //tapBool

  void wordTap() {
    setState(() {
      if (tapBool == true) {
        tapBool = false;
      } else {
        tapBool = true;
      }
    });
    print('tapped');
    print(tapBool);
  }

  Paint paint = Paint()
    ..color = Color.fromRGBO(162, 172, 182, 1)
    ..style = PaintingStyle.fill
    ..strokeJoin = StrokeJoin.round
    ..isAntiAlias = true
    ..strokeWidth = 20.0;
}

class FirstPage extends StatefulWidget {
  @override
  _FirstPageState createState() => _FirstPageState();
}

class _FirstPageState extends State<FirstPage> {
  final bloc = NotesBloc();

  @override
  void dispose() {
    bloc.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return new Scaffold(
      // drawer: MyApp(),

      appBar: AppBar(
        title: new Text("First Page"),
      ),
      body: StreamBuilder<List<Note>>(
          stream: bloc.notes,
          builder: (BuildContext context, AsyncSnapshot<List<Note>> snapshot) {
            if (snapshot.hasData) {
              return ListView.builder(
                itemCount: snapshot.data.length,
                itemBuilder: (BuildContext context, int index) {
                  Note item = snapshot.data[index];
                  return Dismissible(
                    key: UniqueKey(),
                    background: Container(color: Colors.red),

                    child: ListTile(
                      title: Text(item.text),
                      leading: Text(item.id.toString()),

                    ),
                  );
                },
              );
            } else {
              return Center(child: CircularProgressIndicator());
            }
          }),
    );
  }
}

const PrimaryColor = const Color(0xFFFFFFFF);

//var address = getAddress();
//address.setStreet(“Elm”, “13a”);
//address.city = “Carthage”;
//address.state = “Eurasia”
//address.zip(66666, extended: 6666);
//One may write
//
//getAddress()
//..setStreet(“Elm”, “13a”)
//..city = “Carthage”
//..state = “Eurasia”
//..zip(66666, extended: 6666);

//--release --no-track-widget-creation

// word marking catory visible
